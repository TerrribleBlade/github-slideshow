package uk.ac.ncl.csc8404.assessment;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
/**
 *  a rental company class for maintaining the rental record and managing the the motorcycle rental.
 * @author XIAOJIN
 */
public class RentalCompany {
	//get 30 motorcycle from factory
	/**
	 * motormap binds 30 pairs of registration numbers and motorcycles to ensure immutable.
	 */
	private static  Map<RegistrationNumber, Motorcycles>  motorMap = MotorcyclesFactory.getMapInstance("small,large");
	/**
	 * boolean fasle means unrented, true rented.
	 */	private static  Map<RegistrationNumber,Boolean> rentOrNot = MotorcyclesFactory.rentOrNot;
	/**
	 * the record binds the person's driving license and motorcycle's registration number in a map to make sure immutable. It only initialize record once.
	 */
	 private static  Map<DrivingLicence, RegistrationNumber> record = MotorcyclesFactory.record;
	private final static int SMALL_MOTORCYCLE_CAPACITY = 50;
	private final static int LARGE_MOTORCYCLE_CAPACITY = 75;
	/**
	 * 
	 * @param type
	 * @return int  avaliableNumber
	 */
	public int availableMotorcycles(String type){
//	This method returns the number of electric motorcycle of the specified type that are available to rent. 
	      int avaliableNumber = 0;
			RegistrationNumber registrationNumber;
			if(type==null) {
				throw new IllegalArgumentException("No Type Of Motorcycles Found");
			}
			
			if(!"small".equals(type)&&!"large".equals(type)) {
				throw new IllegalArgumentException("No Type Of Motorcycles Found");
			}
			for (Map.Entry<RegistrationNumber, Boolean> m :rentOrNot.entrySet())  {
				//false in rentOrNot means unrented
				if (m.getValue().equals(false)) {
					registrationNumber = m.getKey();
				Motorcycles motorcycles = motorMap.get(registrationNumber);
				int capacity = motorcycles.getCapacity();
				if(type!=null&&type.equals("small")&&capacity==SMALL_MOTORCYCLE_CAPACITY) {
					//count smallMortorcycles
					avaliableNumber++;
				}else if(type!=null&&type.equals("large")&&capacity==LARGE_MOTORCYCLE_CAPACITY){
					avaliableNumber++;
				}

				}}
		return avaliableNumber;
	}

	/**
	 * get all rented motorcycles from the rentOrNot map where value is true.
	 * @return rented motorcycle map.
	 */
	public Map<RegistrationNumber, Motorcycles>  getRentedMotorcycles(){
//	This method returns a collection of all the electric motorcycle currently rented out (if any).
		Map<RegistrationNumber, Motorcycles> rentedMortorcycles = new HashMap<RegistrationNumber, Motorcycles>();
		RegistrationNumber registrationNumber;
		for (Map.Entry<RegistrationNumber, Boolean> m :rentOrNot.entrySet())  {
			//true means rented
		if (m.getValue().equals(true)) {
			registrationNumber = m.getKey();
			//use registrationNumber to get motorcycles in motorMap
			Motorcycles motorcycles = motorMap.get(registrationNumber);
			rentedMortorcycles.put(registrationNumber, motorcycles);

		}}

		return rentedMortorcycles;
}
	/**
	 * get a person's rented motorcycle.
	 * @param person
	 * @return
	 */
	public Motorcycles getMotorcycle(Person person){
//	Given a person, this method returns the electric motorcycle they are currently renting(if any).
		DrivingLicence drivingLicence = person.getDrivingLicence();
		RegistrationNumber registrationNumber = record.get(drivingLicence);
		Map<RegistrationNumber,Motorcycles> rentedMotorcycles = getRentedMotorcycles();
		Motorcycles motorcycles = rentedMotorcycles.get(registrationNumber);
		return motorcycles;
	}
	/**
	 * issue motorcycle to a person.
	 * @param person
	 * @param drivingLicence
	 * @param typeOfMotorcycle
	 */
	public void issueMotorcycle(Person person, DrivingLicence drivingLicence, String typeOfMotorcycle){
		if(typeOfMotorcycle==null) {
			throw new IllegalArgumentException("No Type Of Motorcycles Found.");
		}
		//if a person didn't provide his name then he can't have a driving license.(see the Person class). So driving license probably be null.
		if(drivingLicence==null) {
			throw new IllegalArgumentException("No driving license no rent.");	
		}
		SimpleDateFormat format = new SimpleDateFormat("yyyy");
	    String formatBirthYear = format.format(person.getBirthDate());
	    String formatCurrentYear = format.format(new Date());
	    String formatIssueYear = format.format(drivingLicence.getIssueDate());
	    int birthYear = Integer.parseInt(formatBirthYear);
	    int currentYear = Integer.parseInt(formatCurrentYear);
	    int issueYear = Integer.parseInt(formatIssueYear);		
		boolean fullOrNot = drivingLicence.getFullOrNot();
		if(fullOrNot==false) {
			throw new IllegalArgumentException("can't issue motorcycle to a not full license");

		}else if(availableMotorcycles(typeOfMotorcycle)<1){
			//check the motorcycle in specific type is enough or not
			throw new IllegalArgumentException("not enough"+ typeOfMotorcycle+" motorcycle");

		}
		//check if the person has already rent a motorcycle
		else if(record.get(drivingLicence) != null) {
			throw new IllegalArgumentException(person.getName()+" has already rent a "+typeOfMotorcycle+" motorcycle");
			
		}
		//check the renter's age and license validity
		//issue year less than current year-1 means holding license for one year		
		else if("small".equals(typeOfMotorcycle)&&currentYear-birthYear<20||issueYear>=currentYear-1) {
			throw new IllegalArgumentException(person.getName()+" must be at least 20 years old and must\r\n"
					+ "//	have held their licence for at least 1 year to rent a"+typeOfMotorcycle+" motorcycle.");

		}
		else if("large".equals(typeOfMotorcycle)&&currentYear-birthYear<25||issueYear>=currentYear-5) {
			throw new IllegalArgumentException(person.getName()+" must be at least 25 years old and must\r\n"
					+ "//	have held their licence for at least 5 year to rent a"+typeOfMotorcycle+" motorcycle.");

		}
		
		else {
			//update the record map and rentOrNot map
			//get a registration number from rentOrNot where value equals false
			//put registration number and driving license in record map  
			RegistrationNumber registrationNumber;
			for (Map.Entry<RegistrationNumber, Boolean> m :rentOrNot.entrySet())  {
				//true means rented
				if (m.getValue().equals(false)) {
					registrationNumber = m.getKey();
					Motorcycles motorcycles = motorMap.get(registrationNumber);
					if(motorcycles.getCapacity()==SMALL_MOTORCYCLE_CAPACITY&&typeOfMotorcycle.equals("small")) {
						rentOrNot.put(registrationNumber, true);
						record.put(drivingLicence, registrationNumber);
						return;
					}
					if(motorcycles.getCapacity()==LARGE_MOTORCYCLE_CAPACITY&&typeOfMotorcycle.equals("large")) {
						rentOrNot.put(registrationNumber, true);
						record.put(drivingLicence, registrationNumber);
						return;
					}

				}}
			
		}
		
	}
/**
 * terminate a person's rental.
 * @param person
 * @return battery consumed.
 */
	public int terminateRental(Person person){
		//update the record
		DrivingLicence drivingLicence = person.getDrivingLicence();
		if(record.get(drivingLicence)!=null) {
			RegistrationNumber registrationNumber = record.get(drivingLicence);
			Motorcycles motorcycles = motorMap.get(registrationNumber);
			int currentLevel = motorcycles.getCurrentLevel();
			rentOrNot.put(registrationNumber, false);
			record.remove(drivingLicence);
			if (motorcycles instanceof SmallMotorcycles) {
				motorcycles.setCurrentLevel(SMALL_MOTORCYCLE_CAPACITY);
				motorcycles.setFullCharge(true);
				//it simply reports the amount of charge needed to fill the battery to full capacity.
				return SMALL_MOTORCYCLE_CAPACITY-currentLevel; 
			}
			if (motorcycles instanceof LargeMotorcycles) {
				motorcycles.setCurrentLevel(LARGE_MOTORCYCLE_CAPACITY);
				motorcycles.setFullCharge(true);
				return LARGE_MOTORCYCLE_CAPACITY-currentLevel;
			}			

			
			
		}
		else {//If a person attempts to terminate a non-existent contract, this method does nothing.
			throw new IllegalArgumentException("rental contract not exist!");
		}
		return 0;
	}

	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}


package uk.ac.ncl.csc8404.assessment.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import uk.ac.ncl.csc8404.assessment.LargeMotorcycles;
import uk.ac.ncl.csc8404.assessment.MotorcyclesFactory;
import uk.ac.ncl.csc8404.assessment.RegistrationNumber;
/**
 * @author XIAOJIN
 * 
 */
public class LargeMotorcycleTest {
	private final static String LARGETYPE_STRING= "large";
	private RegistrationNumber registrationNumber;
	private LargeMotorcycles largeMotorcycles;
	private final static int CAPACITY = 75;
	private final static int CONSUME_RATE=2;
	private int currentLevel=13;
	/**
	 * /journey either be full or 0.
	 */
	private static final int KILOMETER =CAPACITY/CONSUME_RATE; 
	private Map<RegistrationNumber,Boolean> rentOrNot;  

@Before
public void setUpLargeMotorcycles() {
	 registrationNumber = RegistrationNumber.getInstance();
	 largeMotorcycles =(LargeMotorcycles) MotorcyclesFactory.getInstance(registrationNumber, LARGETYPE_STRING);
	 rentOrNot= MotorcyclesFactory.rentOrNot;
}
@Test
public void testSetRegistrationNumber() {
	largeMotorcycles.setRegistrationNumber(registrationNumber);
	assertNotNull(largeMotorcycles.getRegistrationNumber());
	
}
@Test
public void testGetRegistrationNumber() {
	largeMotorcycles.setRegistrationNumber(registrationNumber);
	assertNotNull(largeMotorcycles.getRegistrationNumber());

}


@Test
public void testAddCharge() {
	largeMotorcycles.setCurrentLevel(0);
	largeMotorcycles.addCharge(22);
	assertEquals(22,largeMotorcycles.getCurrentLevel());
}
/**
 * 	 test a motorcycle cannot be ridden if it is not currently rented.

 */
@Test (expected = IllegalArgumentException.class)
public void testRideUnrented() {
	largeMotorcycles.setRegistrationNumber(registrationNumber);
	rentOrNot.put(largeMotorcycles.getRegistrationNumber(), false);
	largeMotorcycles.ride(KILOMETER);
	
}
/**
 * 	 test a  rented motorcycle cannot be ridden if it has  fewer kWh of charge in its battery.

 */
@Test (expected = IllegalArgumentException.class)
public void testRideFewBattery() {
	largeMotorcycles.setRegistrationNumber(registrationNumber);
	rentOrNot.put(largeMotorcycles.getRegistrationNumber(), true);
	largeMotorcycles.setCurrentLevel(13);
	largeMotorcycles.ride(KILOMETER);

}

/**
 * 	 test a  rented motorcycle cannot be ridden if it has 0  kWh of charge in its battery.

 */
@Test (expected = IllegalArgumentException.class)
public void testRideZeroBattery() {
	largeMotorcycles.setRegistrationNumber(registrationNumber);
	//rented.
	rentOrNot.put(largeMotorcycles.getRegistrationNumber(), true);
	largeMotorcycles.setCurrentLevel(0);
	largeMotorcycles.setFullCharge(false);
	largeMotorcycles.ride(KILOMETER);

}
/**
 *  test riding a rented motorcycle with 0 journey with full battery.
 * 
 */
@Test (expected = IllegalArgumentException.class)
public void testRideZeroJourney() {
	largeMotorcycles.setRegistrationNumber(registrationNumber);
	//rented.
	rentOrNot.put(largeMotorcycles.getRegistrationNumber(), true);
	largeMotorcycles.setFullCharge(true);
	largeMotorcycles.ride(0);
}
/**
 *  test riding a rented motorcycle with full journey and assert the kwh consumed.
 */
@Test
public void testRide() {
	largeMotorcycles.setRegistrationNumber(registrationNumber);
	//rented.
	rentOrNot.put(largeMotorcycles.getRegistrationNumber(), true);
	largeMotorcycles.setFullCharge(true);
	assertEquals(74, largeMotorcycles.ride(KILOMETER));

}


@Test
public void setGetCapacity() {
	
assertEquals(75, largeMotorcycles.getCapacity());}


@Test
public void testGetCurrentLevel() {
	largeMotorcycles.setCurrentLevel(currentLevel);
	assertEquals(13, largeMotorcycles.getCurrentLevel());
}

@Test
public void testSetCurrentLevel() {
	largeMotorcycles.setCurrentLevel(currentLevel);
	assertEquals(13, largeMotorcycles.getCurrentLevel());
}


@Test
public void testIsFullCharge() {
	largeMotorcycles.setCurrentLevel(currentLevel);
	assertFalse(largeMotorcycles.isFullCharge());
	largeMotorcycles.setCurrentLevel(CAPACITY);
	assertTrue(largeMotorcycles.isFullCharge());
}

@Test
public void testSetFullCharge() {
	largeMotorcycles.setFullCharge(true);
	assertEquals(largeMotorcycles.getCurrentLevel(), CAPACITY);
}
}

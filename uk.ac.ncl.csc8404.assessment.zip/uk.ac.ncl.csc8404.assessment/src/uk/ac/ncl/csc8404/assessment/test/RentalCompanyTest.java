package uk.ac.ncl.csc8404.assessment.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.util.Date;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import uk.ac.ncl.csc8404.assessment.DrivingLicence;
import uk.ac.ncl.csc8404.assessment.Motorcycles;
import uk.ac.ncl.csc8404.assessment.MotorcyclesFactory;
import uk.ac.ncl.csc8404.assessment.Person;
import uk.ac.ncl.csc8404.assessment.RegistrationNumber;
import uk.ac.ncl.csc8404.assessment.RentalCompany;
/**
 *  test rental company.
 * @author XIAOJIN
 */
public class RentalCompanyTest {
	private Map<RegistrationNumber, Motorcycles> mortorMap = MotorcyclesFactory.getMapInstance("small,large");
	private Map<RegistrationNumber,Boolean> rentOrNot = MotorcyclesFactory.rentOrNot;
	private Map<DrivingLicence, RegistrationNumber> record = MotorcyclesFactory.record;
	private final static String SMALLTYPE_STRING= "small";
	private final static String LARGE_STRING= "large";
	private RentalCompany rentalCompany = new RentalCompany();
	
	private Person person;

	@Before
	public void setUpRentalCompany() {
		person= new Person();
		person.setBirthDate(new Date());
		person.setName("JamesBond");
		person.setDrivingLicence();
	}
	/**
	 * test getting a specific type available motorcycles with specific type.
	 */
	@Test
	public void testAvailableMotorcycles() {
		assertEquals(20, rentalCompany.availableMotorcycles(SMALLTYPE_STRING));
		assertEquals(10, rentalCompany.availableMotorcycles(LARGE_STRING));

	}
	@Test
	public void testGetRentedMotorcycles() {
		rentalCompany.getRentedMotorcycles();
		assertNotNull(rentalCompany.getRentedMotorcycles());
	}
	/**
	 * test getting a specific type available motorcycles with invalid type.
	 */
	
	@Test(expected = IllegalArgumentException.class)
	public void testAvailableMotorcyclesInvalidType() {
		 rentalCompany.availableMotorcycles("hahahahaa");
	}
  /**
    *  test getting a specific type available motorcycles with null type.
    */
	@Test(expected = IllegalArgumentException.class)
	public void testAvailableMotorcyclesNullType() {
		 rentalCompany.availableMotorcycles(null);
	}
	
	/**
	 * test issuing a unknown type motorcycle.
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testIssueUnknownMotorcycle() {
		person.setBirthDate(new Date());
		person.getDrivingLicence().setFullOrNot(true);
		rentalCompany.issueMotorcycle(person, person.getDrivingLicence(), null);
	}
	/**
	 * test issuing a motorcycle to a no license person.
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testIssueWithoutLicense() {
		person.setBirthDate(new Date());
		person.getDrivingLicence().setFullOrNot(true);
		rentalCompany.issueMotorcycle(person, null, SMALLTYPE_STRING);
	}
	/**
	 * test issuing a small Motorcycle to an age under 20 person with full license. 
	 */
	
	@Test(expected = IllegalArgumentException.class)
	public void testIssueSmallMotorcycleLessThanTwenty() {
		person.setBirthDate(new Date());
		person.getDrivingLicence().setFullOrNot(true);
		rentalCompany.issueMotorcycle(person, person.getDrivingLicence(), LARGE_STRING);
	}
	/**
	 * test issuing a small motorcycle to an age at least 20 with full license with holding less than 1 year.
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testIssueSmallMotorcyAtTwenty() {
		   int birthYear = 2000;
		   // test the boundary of birth date which is 31/12/2000.
		   LocalDate localDate = LocalDate.of(birthYear, Month.DECEMBER, 31);
	        Date birthDate = Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
	        person.setBirthDate(birthDate);
	        person.setAge();
	        DrivingLicence drivingLicence = new DrivingLicence("JB-2000-1697274067602", new Date(), true); 
	        rentalCompany.issueMotorcycle(person, drivingLicence, SMALLTYPE_STRING);

	        
	}
	/**
	 * test issuing a large motorcycle to an age over 25 person with full license and holding over 5 years.
	 * notice: when person object is created it will initialize a random driving license for him. So if you want to test a proper
	 * license, the best way is to new a license in manual.
	 */
	@Test
	public void testIssueLargeMotorcycle() {
		   int birthYear = 1989;
		   int issueYear =1997;
		   // assume born in January 1st.
	        LocalDate localDate = LocalDate.of(birthYear, Month.JANUARY, 1);
	        Date birthDate = Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
	        person.setBirthDate(birthDate);
	        person.setAge();
	        //assume issued in January 1st.
	        localDate = LocalDate.of(issueYear, Month.JANUARY, 1);
	        Date issuDate = Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
	        DrivingLicence drivingLicence = new DrivingLicence("JB-1997-1697274067602", issuDate, true);      
	        rentalCompany.issueMotorcycle(person, drivingLicence, LARGE_STRING);

	}

	/**
	 * test issuing a person with not enough specific motorcycle.
	 *
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testIssueNotEnoughMotorcycle() {
		   int birthYear = 1989;
		   int issueYear =1997;
		   // assume born in January 1st.
	        LocalDate localDate = LocalDate.of(birthYear, Month.JANUARY, 1);
	        Date birthDate = Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
	        person.setBirthDate(birthDate);
	        person.setAge();
	        //assume issued in January 1st.
	        localDate = LocalDate.of(issueYear, Month.JANUARY, 1);
	        Date issuDate = Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
	        DrivingLicence drivingLicence = new DrivingLicence("JB-1997-1697274067602", issuDate, true);    
	        //modify rentOrNot map value rent=true.
	        for (Map.Entry<RegistrationNumber,Boolean> entry : rentOrNot.entrySet()) {
	            entry.setValue(true);
	        }
	        rentalCompany.issueMotorcycle(person, drivingLicence, LARGE_STRING);
	}
	/**
	 *  test issuing a person who has already rent a motorcycle.
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testIssueAlreadyRent() {
		person.setBirthDate(new Date());
		person.getDrivingLicence().setFullOrNot(true);
		record.put(person.getDrivingLicence(), RegistrationNumber.getInstance());
		rentalCompany.issueMotorcycle(person, person.getDrivingLicence(), LARGE_STRING);
	}
	/**
	 *  test getting a rented motorcycle of a person.
	 */
	@Test
	public void testGetMotorcycle() {
		person.setBirthDate(new Date());
		person.getDrivingLicence().setFullOrNot(true);
		RegistrationNumber registrationNumber = RegistrationNumber.getInstance();
		mortorMap.put(registrationNumber, MotorcyclesFactory.getInstance(registrationNumber, SMALLTYPE_STRING));
		record.put(person.getDrivingLicence(), registrationNumber);
		rentOrNot.put(registrationNumber, true);
	    assertNotNull(rentalCompany.getMotorcycle(person));
	}

	/**
	 *  test normal termination of a rental
	 */
	@Test
	public void testTerminateRental() {
		person.setBirthDate(new Date());
		DrivingLicence drivingLicence = person.getDrivingLicence();
		drivingLicence.setFullOrNot(true);
		RegistrationNumber registrationNumber = RegistrationNumber.getInstance();
		Motorcycles motorcycles = MotorcyclesFactory.getInstance(registrationNumber, SMALLTYPE_STRING);
		motorcycles.setCurrentLevel(22);
		mortorMap.put(registrationNumber, motorcycles);
		record.put(drivingLicence, registrationNumber);
		// prepare data that a person has a rented motorcycle.
		rentOrNot.put(registrationNumber, true);
		//return the amount of charge needed to fill the battery to full capacity
		int needCharge = rentalCompany.terminateRental(person);
		//removes the record of the rental from the company's records.
		assertFalse(record.containsKey(drivingLicence)); 
		//rentOrNot value shall be false
		assertFalse(rentOrNot.get(registrationNumber));
		// capacity-current level = 50-22 
		assertEquals(28, needCharge);

	}
	/**
	 *  test a person without contract trying to terminate rental.
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testTerminateUnexistRental() {
		person.setBirthDate(new Date());
		DrivingLicence drivingLicence = person.getDrivingLicence();
		drivingLicence.setFullOrNot(true);
		RegistrationNumber registrationNumber = RegistrationNumber.getInstance();
		Motorcycles motorcycles = MotorcyclesFactory.getInstance(registrationNumber, SMALLTYPE_STRING);
		motorcycles.setCurrentLevel(22);
		mortorMap.put(registrationNumber, motorcycles);
		rentOrNot.put(registrationNumber, true);
		rentalCompany.terminateRental(person);
	}
	/**
	 * clean data to prevent different test method sharing the same map which will generating more motorcycle.
	 */ 
	@After
	public void clean() {
		mortorMap.clear();
		rentOrNot.clear();
		record.clear();
	}
}

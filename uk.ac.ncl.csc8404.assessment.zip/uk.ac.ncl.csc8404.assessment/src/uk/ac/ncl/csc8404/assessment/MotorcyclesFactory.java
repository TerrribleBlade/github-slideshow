package uk.ac.ncl.csc8404.assessment;

import java.util.HashMap;
import java.util.Map;

/**
 * @author XIAOJIN
 * @Description a motorcycle factory for creating different types of motorcycles.
 */
public abstract class MotorcyclesFactory implements Motorcycles{
	MotorcyclesFactory(RegistrationNumber number){}
	/**
	 * a new batch of motorcycles.
	 */
	public static Map<RegistrationNumber, Motorcycles>  inStock = new HashMap<RegistrationNumber, Motorcycles>();
	/**
	 * boolean fasle means unrented, true rented.
	 */
	public static Map<RegistrationNumber, Boolean> rentOrNot = new HashMap<RegistrationNumber, Boolean>();
	/**
	 * the record binds the person's driving license and motorcycle's registration number in a map to make sure immutability.
	 */
	public static Map<DrivingLicence, RegistrationNumber> record = new HashMap<DrivingLicence, RegistrationNumber>();
	private final static int SMALL_MOTORCYCLE_CAPACITY = 50;
	private final static int LARGE_MOTORCYCLE_CAPACITY = 75;
	public static Motorcycles getInstance(RegistrationNumber number,String type) {
		// produce a specific type of motorcycle. 
		if (type!=null&&type.equals("small")){	
			return new SmallMotorcycles(number,type,SMALL_MOTORCYCLE_CAPACITY);
			} else if (type!=null&&type.equals("large")) {
			return new LargeMotorcycles(number,type,LARGE_MOTORCYCLE_CAPACITY);
			} else {
			throw new IllegalArgumentException("No Type Of Motorcycles Found");
			}

	}
	
	/**
	 * create 20 small and 10 large motorcycle and bind them with the registration number, once create a motorcycle, set rentOrNot value false binding with registration number
	 * @param type
	 * @return   Map<RegistrationNumber, Motorcycles> instock
	 */
	public static Map<RegistrationNumber, Motorcycles> getMapInstance(String type) {
		//If it has already contain 20 small and 10 large motorcycle,stop generating. If not doing this, every time JUnit invoking this method will generate more and more motorcycles.
		if(inStock.size()==30) {
			return inStock;
		}
		if(type==null||!type.contains(",")) {
			throw new IllegalArgumentException("No Type Of Motorcycles Found");
		}
		String[] split = type.split(",");
		if (split[0]!=null&&split[0].equals("small")){		
			for (int i=0; i<20; i++) {
				RegistrationNumber registrationNumber = RegistrationNumber.getInstance();
				Motorcycles smallMotorcycles = getInstance(registrationNumber, "small");
				smallMotorcycles.setRegistrationNumber(registrationNumber);
				smallMotorcycles.setCurrentLevel(SMALL_MOTORCYCLE_CAPACITY);
				smallMotorcycles.setFullCharge(true);
				inStock.put(registrationNumber, smallMotorcycles);
				rentOrNot.put(registrationNumber, false);
				
			}
			}  if (split[1]!=null&&split[1].equals("large")) {
				for (int i=0; i<10; i++) {
					RegistrationNumber registrationNumber = RegistrationNumber.getInstance();
					Motorcycles largeMotorcycles = getInstance(registrationNumber, "large");
					largeMotorcycles.setRegistrationNumber(registrationNumber);
					largeMotorcycles.setCurrentLevel(LARGE_MOTORCYCLE_CAPACITY);
					largeMotorcycles.setFullCharge(true);
					inStock.put(registrationNumber, largeMotorcycles);
					rentOrNot.put(registrationNumber, false);
				}
			} else {
			throw new IllegalArgumentException("No Type Of Motorcycles Found");
			}
		return inStock;

	}
	

	

	



	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
 
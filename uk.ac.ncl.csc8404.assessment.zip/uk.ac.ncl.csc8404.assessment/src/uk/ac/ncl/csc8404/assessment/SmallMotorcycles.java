package uk.ac.ncl.csc8404.assessment;

import java.util.Map;
/** a small motorcycle class
 * @author XIAOJIN
 * 
 */
public class SmallMotorcycles  implements Motorcycles{
	private RegistrationNumber registrationNumber;
	private static final int CAPACITY=50;
	private static final int CONSUME_RATE=1;
	/**
	 * if a new smallMotorcycle is created, default setting is full charge
	 */
	private boolean fullCharge=true;
	private int currentLevel;
	/**
	 * set the registration number when construct a registration instance.
	 * @param number
	 * @param type
	 * @param capacity
	 */
public SmallMotorcycles(RegistrationNumber number,String type,int capacity) {
	this.registrationNumber = number;
	}


	@Override
	public RegistrationNumber getRegistrationNumber() {
		//A method to get the motorcycle's registration number.
		return registrationNumber;
	}

	@Override
	public int getCapacity() {
		//A method to get the capacity in kilowatt-hours (kWh) of the motorcycle's battery.		
		return CAPACITY;
	}

	@Override
	public int getCurrentLevel() {
		// A method to get the current charge level in kWh in the battery.
		return currentLevel;
	}
	@Override
	public void setCurrentLevel(int currentLevel) {
		// A method to for the factory to initialize the current charge level in kWh in the battery.
		this.currentLevel=currentLevel;
	}

	@Override
	public boolean isFullCharge() {
		//A method that indicates whether the motorcycle's battery is fully charged or not.
		if(getCurrentLevel()<CAPACITY) {
			this.fullCharge=false;
			return fullCharge;
		}
		else{
			this.fullCharge=true;
			return fullCharge;}
	}

	/**
	 * @param fullCharge the fullCharge to set
	 */
	@Override
	public void setFullCharge(boolean fullCharge) {
		if(fullCharge==true) {
			setCurrentLevel(CAPACITY);	
		}
		this.fullCharge = fullCharge;
	}	 
	/**
	 * A method to add a given amount of charge in kWh to the battery (up to the battery's capacity) and which, after execution, indicates how much charge was added.
	 */
	@Override
	public int addCharge(int charge) {
		setCurrentLevel(getCurrentLevel()+charge);				
		return charge;
	}	
	@Override
	public int ride(int kilometers) {
		int kWhConsumed=0;
		int currentLevel = getCurrentLevel();
		RegistrationNumber registrationNumber = getRegistrationNumber();
		RentalCompany rentalCompany = new RentalCompany();
		//A motorcycle cannot be ridden if it is not currently rented.
		Map<RegistrationNumber,Motorcycles> rentedMotorcycles = rentalCompany.getRentedMotorcycles();
		if(!rentedMotorcycles.containsKey(registrationNumber)) {
			throw new IllegalArgumentException("this motorcycle cannot be ridden because it is not currently rented.");

		//A motorcycle cannot be ridden if it has 0 or fewer kWh of charge in its battery.
		}else if(currentLevel<=0||currentLevel<CONSUME_RATE*kilometers) {
			throw new IllegalArgumentException("this motorcycle cannot be ridden because it has 0 or fewer kWh of charge in its battery.");

		}
		// All journeys are either for 0 km (the motorcycle cannot be ridden) or for the full distance specified as a parameter to the ride method.
		else if(kilometers==0){
			throw new IllegalArgumentException("this motorcycle cannot be ridden because the journey is 0 km.");
		}
		else {
			kWhConsumed= kilometers*CONSUME_RATE;
			//The ride method calculates the amount of energy consumed during a journey, deducts that amount from the charge in the battery, and returns the kWh consumed.
			setCurrentLevel(currentLevel-kWhConsumed);
		}

		return kWhConsumed;
	}


@Override
	public String toString() {
		return "SmallMotorcycles [registrationNumber=" + registrationNumber + ", fullCharge=" + fullCharge
				+ ", currentLevel=" + currentLevel + "]";
	}

@Override
public void setRegistrationNumber(RegistrationNumber registrationNumber) {
	this.registrationNumber= registrationNumber;
}





}

package uk.ac.ncl.csc8404.assessment.test;

import static org.junit.Assert.assertEquals;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;

import uk.ac.ncl.csc8404.assessment.Person;
/**
 *  test person object.
 * @author XIAOJIN
 */
public class PersonTest {
	private String name;
	private Date birthDate;
	@Before
	public void setUpPerson() {
		name="JameSmith";
		birthDate= new Date();
	}

	@Test
	public void testSetName() {
		Person person = new Person();
		person.setName(name);
		assertEquals("JameSmith", person.getName());
	}
	@Test
	public void testSetAge() {
		Person person = new Person();
		person.setBirthDate(new Date());
		person.setAge();
	} 
	
	@Test 
	public void testGetAge() {
		Person person = new Person();
		person.setBirthDate(new Date());
		person.setAge();
		assertEquals(0, person.getAge());
	}
	@Test
	public void testSetBirthDate() {
		Person person =new Person();
		person.setBirthDate(birthDate);
		assertEquals(birthDate, person.getBirthDate());
	}
	@Test
	public void testGetName() {
		Person person =new Person();
		person.setName(name);		
		assertEquals("JameSmith", person.getName());
	}
	
	
	@Test
	public void testGetBirthDate() {
		Person person =new Person();
		person.setBirthDate(birthDate);
		assertEquals(birthDate, person.getBirthDate());
	}
	@Test(expected = IllegalArgumentException.class)
	public void testSetDrivingLicenceFailure() {
		Person person = new Person();
		person.setDrivingLicence();
	}
	
	@Test
	public void testSetDrivingLicence() {
		Person person = new Person();
		person.setName(name);
		person.setBirthDate(birthDate);
		person.setDrivingLicence();
	}
	@Test
	public void testGetDrivingLicence() {
		Person person = new Person();
		person.setName(name);
		person.setBirthDate(birthDate);
		person.setDrivingLicence();
		person.getDrivingLicence();
	}
	
}

package uk.ac.ncl.csc8404.assessment.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import uk.ac.ncl.csc8404.assessment.MotorcyclesFactory;
import uk.ac.ncl.csc8404.assessment.RegistrationNumber;
import uk.ac.ncl.csc8404.assessment.SmallMotorcycles;
/**
 *  test small motorcycle.
 * @author XIAOJIN
 */
public class SmallMotorcycleTest {
	private final static String SMALLTYPE_STRING= "small";
	private RegistrationNumber registrationNumber;
	private SmallMotorcycles smallMotorcycles;
	private final static int CAPACITY = 50;
	private int currentLevel=13;
	private static final int KILOMETER =50;
	private Map<RegistrationNumber,Boolean> rentOrNot; 

@Before
public void setUpSmallMotorcycle() {
	 registrationNumber = RegistrationNumber.getInstance();
	 smallMotorcycles =(SmallMotorcycles) MotorcyclesFactory.getInstance(registrationNumber, SMALLTYPE_STRING);
	 rentOrNot= MotorcyclesFactory.rentOrNot;
}
@Test
public void testSetRegistrationNumber() {
	smallMotorcycles.setRegistrationNumber(registrationNumber);
	assertNotNull(smallMotorcycles.getRegistrationNumber());
	
}
@Test
public void testGetRegistrationNumber() {
	smallMotorcycles.setRegistrationNumber(registrationNumber);
	assertNotNull(smallMotorcycles.getRegistrationNumber());

}


@Test
public void testAddCharge() {
	smallMotorcycles.setCurrentLevel(0);
	smallMotorcycles.addCharge(22);
	assertEquals(22,smallMotorcycles.getCurrentLevel());
}
/**
 * 	 test a motorcycle cannot be ridden if it is not currently rented.

 */
@Test (expected = IllegalArgumentException.class)
public void testRideUnrented() {
	smallMotorcycles.setRegistrationNumber(registrationNumber);
	rentOrNot.put(smallMotorcycles.getRegistrationNumber(), false);
	smallMotorcycles.ride(KILOMETER);
	
}
/**
 * 	 test a  rented motorcycle cannot be ridden if it has  fewer kWh of charge in its battery.

 */
@Test (expected = IllegalArgumentException.class)
public void testRideFewBattery() {
	smallMotorcycles.setRegistrationNumber(registrationNumber);
	rentOrNot.put(smallMotorcycles.getRegistrationNumber(), true);
	smallMotorcycles.setCurrentLevel(13);
	smallMotorcycles.ride(KILOMETER);

}

/**
 * 	 test a  rented motorcycle cannot be ridden if it has 0  kWh of charge in its battery.

 */
@Test (expected = IllegalArgumentException.class)
public void testRideZeroBattery() {
	smallMotorcycles.setRegistrationNumber(registrationNumber);
	//rented.
	rentOrNot.put(smallMotorcycles.getRegistrationNumber(), true);
	smallMotorcycles.setCurrentLevel(0);
	smallMotorcycles.setFullCharge(false);
	smallMotorcycles.ride(KILOMETER);

}
/**
 *  test riding a rented motorcycle with 0 journey with full battery.
 * 
 */
@Test (expected = IllegalArgumentException.class)
public void testRideZeroJourney() {
	smallMotorcycles.setRegistrationNumber(registrationNumber);
	//rented.
	rentOrNot.put(smallMotorcycles.getRegistrationNumber(), true);
	smallMotorcycles.setFullCharge(true);
	smallMotorcycles.ride(0);
}
/**
 *  test riding a rented motorcycle with full journey and assert the kwh consumed.
 */
@Test
public void testRide() {
	smallMotorcycles.setRegistrationNumber(registrationNumber);
	//rented.
	rentOrNot.put(smallMotorcycles.getRegistrationNumber(), true);
	smallMotorcycles.setFullCharge(true);
	assertEquals(50, smallMotorcycles.ride(KILOMETER));

}


@Test
public void setGetCapacity() {
	
assertEquals(50, smallMotorcycles.getCapacity());}


@Test
public void testGetCurrentLevel() {
	smallMotorcycles.setCurrentLevel(currentLevel);
	assertEquals(13, smallMotorcycles.getCurrentLevel());
}

@Test
public void testSetCurrentLevel() {
	smallMotorcycles.setCurrentLevel(currentLevel);
	assertEquals(13, smallMotorcycles.getCurrentLevel());
}


@Test
public void testIsFullCharge() {
	smallMotorcycles.setCurrentLevel(currentLevel);
	assertFalse(smallMotorcycles.isFullCharge());
	smallMotorcycles.setCurrentLevel(CAPACITY);
	assertTrue(smallMotorcycles.isFullCharge());
}

@Test
public void testSetFullCharge() {
	smallMotorcycles.setFullCharge(true);
	assertEquals(smallMotorcycles.getCurrentLevel(), CAPACITY);
}


}
package uk.ac.ncl.csc8404.assessment;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;
import java.util.Random;
/**
 * @author XIAOJIN
 * @Description a person (or a renter) class.
 */
public class Person {
	private String name;
	private Date birthDate;
	private DrivingLicence drivingLicence;
	/**
	 * supporting field calculated through birth date.
	 */
	private int age;
	/**
	 * @return the age
	 */
	public int getAge() {
		return age;
	}
	/**
	 * @param age the age to set
	 */
	public void setAge() {
		SimpleDateFormat format = new SimpleDateFormat("yyyy");
	    int currentYear=Integer.parseInt(format.format(new Date()));
	    int birthYear=Integer.parseInt(format.format(this.getBirthDate()));
		this.age = currentYear-birthYear;
	}
	/**
	 * @return the drivingLicence
	 */
	public DrivingLicence getDrivingLicence() {
		return this.drivingLicence;
	}
	/**
	 * @param  the drivingLicence for a person to set
	 * @throws ParseException 
	 */
	public void setDrivingLicence()  {
		String number="";
		if(this.getName()!=null) {
			String name = this.getName();
		char[] charArray = name.toCharArray();
		// first part: find uppercase in person's name
		for (int i=0;i<charArray.length;i++) {
			if(Character.isUpperCase(charArray[i])) {
				number+=charArray[i];
			}
		}
		//second part: Randomly generate a year
		 SimpleDateFormat format = new SimpleDateFormat("yyyy");
		    String formatYear = format.format(new Date());
		    String birthdate = format.format(getBirthDate());
		    int parseIntYear = Integer.parseInt(formatYear);
		    int parseIntBirthDate =Integer.parseInt(birthdate);
		    Random random =new Random();
			//issue year must at least greater than the person birth year.So generate number between birthday and current year 
			int randomIssueYear = random.nextInt(parseIntYear-parseIntBirthDate+1)+parseIntBirthDate+1;
		 String issueYearString = String.valueOf(randomIssueYear);
		 Date issueDate;
		try {
			issueDate = format.parse(issueYearString);
			//third part: generate a currentTimeMillis to ensure the number is immutable
			long currentTimeMillis = System.currentTimeMillis();
			String currentTimeMillisString = String.valueOf(currentTimeMillis);
			number=number+"-"+issueYearString+"-"+currentTimeMillisString;
			DrivingLicence drivingLicence = new DrivingLicence(number, issueDate, false);
			this.drivingLicence = drivingLicence;
		} catch (ParseException e) {
			e.printStackTrace();
		}
		}
		else {
			throw new IllegalArgumentException("A person can't obtain a driving license because he doesn't provide his name!");
		}
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", birthDate=" + birthDate + ", drivingLicence=" + drivingLicence + ", age="
				+ age + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(birthDate, name);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;}
		if (obj == null) {
			return false;}
		if (getClass() != obj.getClass()) {
			return false;}
		Person other = (Person) obj;
		return Objects.equals(birthDate, other.birthDate) && Objects.equals(name, other.name) && Objects.equals(drivingLicence, other.drivingLicence);
	}
	public Person() {
		super();
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the birthDate
	 */
	public Date getBirthDate() {
		return birthDate;
	}
	/**
	 * @param birthDate the birthDate to set
	 */
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

}

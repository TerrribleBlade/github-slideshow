package uk.ac.ncl.csc8404.assessment.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.lang.ref.Cleaner.Cleanable;
import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import uk.ac.ncl.csc8404.assessment.Motorcycles;
import uk.ac.ncl.csc8404.assessment.MotorcyclesFactory;
import uk.ac.ncl.csc8404.assessment.RegistrationNumber;
/**
 * @author XIAOJIN
 * @Descrpiton test creating motorcycles. 
 */

public class MotorcyclesFactoryTest {
	Map<RegistrationNumber,Motorcycles> mapInstance = new HashMap<RegistrationNumber, Motorcycles>();

	private String type1;
	private String type2;
	private String type3;
	private String type4;
	private String type5;
	private static final int SMALL_MOTORCYCLE_CAPACITY=50;
	private static final int LARGE_MOTORCYCLE_CAPACITY=75;
	@Before
	public void setUpMotorcycleFactoryClass() {
		 	
		 type1 = "small";
		 type2= "large";
		 type3="small,large";
		 type4="aaaaaa";
		 type5="999,666";
	}
	/**
	 * 
	 * test using a valid type type1 and type2 to create a specific type motorcycles with no registration number.
	 */
	@Test 
	public void testGetInstance() {
		Motorcycles motorcycles = MotorcyclesFactory.getInstance(null, type1);
		assertNotNull(motorcycles);
		 motorcycles = MotorcyclesFactory.getInstance(null, type2);
		assertNotNull(motorcycles);

		
	}
	@Test (expected = IllegalArgumentException.class)
	public void testGetInstanceFailure() {
		MotorcyclesFactory.getInstance(null, null);
	 MotorcyclesFactory.getInstance(null, type3);
		
	}
	/**
	 * test using a valid type type3 to create 20 small motorcycles and 10 large motorcycles.
	 */
	@Test
	public void testGetMapInstance(){
		 mapInstance = MotorcyclesFactory.getMapInstance(type3);
		assertNotNull(mapInstance);
		assertEquals(30, mapInstance.size());
		int countSmallMotorcycle=0;
		int countLargeMotorcycle=0;
		for (Map.Entry<RegistrationNumber, Motorcycles> m :mapInstance.entrySet())  {
			//false in rentOrNot means unrented
			if (m.getValue().getCapacity()==SMALL_MOTORCYCLE_CAPACITY) {
				countSmallMotorcycle++;
			}
			if(m.getValue().getCapacity()==LARGE_MOTORCYCLE_CAPACITY) {
				countLargeMotorcycle++;
			}}
		assertEquals(20, countSmallMotorcycle);
		assertEquals(10, countLargeMotorcycle);
	}
	/**
	 * test using a invalid type type4 and type5 to create 20 small motorcycles and 10 large motorcycles.
	 */
	@Test (expected = IllegalArgumentException.class)
	public void testGetMapInstanceFailure() {
		mapInstance=MotorcyclesFactory.getMapInstance(type4);		
		mapInstance=MotorcyclesFactory.getMapInstance(type5);

	}

	@After
	public void clean() {
		mapInstance.clear();
	}
}

package uk.ac.ncl.csc8404.assessment.test;

import static org.junit.Assert.assertEquals;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;

import uk.ac.ncl.csc8404.assessment.DrivingLicence;

/**
 * @author XIAOJIN
 * @Description
 */
public class DrivingLicenceTest {
	private String  number;
	private Date issueDate;
	private boolean fullOrNot;
	DrivingLicence drivingLicence;
	@Before
	public void setUpDrivingLicence() {
		number="MS-1990-10";
		issueDate= new Date();
		fullOrNot= true;
	    drivingLicence = new DrivingLicence(number, issueDate, fullOrNot);
	}
	
	@Test
	public void testSetNumber() {
		drivingLicence.setNumber(number);
		assertEquals("MS-1990-10", drivingLicence.getNumber());
	}
	@Test
	public void testGetNumber() {
		drivingLicence.setNumber(number);
		assertEquals("MS-1990-10",drivingLicence.getNumber());

		
	}
	@Test
	public void testSetIssuDate() {
		drivingLicence.setIssueDate(issueDate);
		assertEquals(issueDate, drivingLicence.getIssueDate());
	}
	@Test
	public void testGetIssueDate() {
		drivingLicence.setIssueDate(issueDate);
		assertEquals(issueDate,drivingLicence.getIssueDate());
	}
	@Test
	public void testSetFullOrNot() {
		drivingLicence.setFullOrNot(fullOrNot);
		assertEquals(fullOrNot, drivingLicence.getFullOrNot());
	}
	@Test
	public void testGetFullOrNot() {
		drivingLicence.setFullOrNot(fullOrNot);
		assertEquals(fullOrNot, drivingLicence.getFullOrNot());
	}
	
}

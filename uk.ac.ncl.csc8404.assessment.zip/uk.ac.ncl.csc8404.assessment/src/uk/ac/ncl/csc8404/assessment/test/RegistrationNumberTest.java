package uk.ac.ncl.csc8404.assessment.test;

import static org.junit.Assert.assertFalse;

import org.junit.Before;
import org.junit.Test;

import uk.ac.ncl.csc8404.assessment.RegistrationNumber;

/**
 *test generating different registration number.
 *  all registration numbers are randomly generated,  no parameter needs to be set.
 * @author XIAOJIN
 */
public class RegistrationNumberTest {
	@Before
	public void setUpMotorRegistrationNumberClass() {
		
	}
	@Test
	public void getInstance() {
		RegistrationNumber number1 = RegistrationNumber.getInstance();
		RegistrationNumber number2 = RegistrationNumber.getInstance();
		assertFalse(number1.toString().equals(number2.toString()));
	}
}

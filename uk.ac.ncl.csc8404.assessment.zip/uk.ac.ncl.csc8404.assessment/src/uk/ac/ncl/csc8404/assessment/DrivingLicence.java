package uk.ac.ncl.csc8404.assessment;
import java.util.Date;
import java.util.Objects;

/**
 * @author XIAOJIN
 * @Description 
 */
public final class DrivingLicence {
	private String  number;
	private Date issueDate;
	
	/**
	 * if false, means can't issue motorcycle.
	 */
	private boolean fullOrNot; 
	/**
	 * @return the driving license number.
	 */
	public String getNumber() {
		return number;
	}
	/**
	 * @param number the number to set
	 */
	public void setNumber(String number) {
		//don't generate a person object to create a licence number here,because logically a person isn't belong to licence.
		this.number = number;
	}
	public DrivingLicence(String number, Date issueDate, boolean fullOrNot) {
		super();
		this.number = number;
		this.issueDate = issueDate;
		this.fullOrNot = fullOrNot;
	}
	/**
	 * @return the issueDate
	 */
	public Date getIssueDate() {
		return issueDate;
	}
	/**
	 * @param issueDate the issueDate to set
	 */
	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}
	/**
	 * @return the fullOrNot
	 */
	public boolean getFullOrNot() {
		return this.fullOrNot;
	}
	/**
	 * @param fullOrNot the fullOrNot to set
	 */
	public void setFullOrNot(boolean fullOrNot) {
		this.fullOrNot = fullOrNot;
	}
	@Override
	public int hashCode() {
		return Objects.hash(fullOrNot, issueDate, number);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;}
		if (obj == null) {
			return false;}
		if (getClass() != obj.getClass()) {
			return false;}
		DrivingLicence other = (DrivingLicence) obj;
		return fullOrNot == other.fullOrNot && Objects.equals(issueDate, other.issueDate)
				&& Objects.equals(number, other.number);
	}
	@Override
	public String toString() {
		return "DrivingLicence [number=" + number + ", issueDate=" + issueDate + ", fullOrNot=" + fullOrNot + "]";
	}
	
}

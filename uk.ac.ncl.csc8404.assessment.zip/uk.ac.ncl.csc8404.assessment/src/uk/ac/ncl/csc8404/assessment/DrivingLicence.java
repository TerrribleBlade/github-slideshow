package uk.ac.ncl.csc8404.assessment;
import java.util.Date;
import java.util.Objects;

/**
 * a driving licence class
 * @author XIAOJIN
 * 
 */
public final class DrivingLicence {
	private String  number;
	private Date issueDate;
	
	/**
	 * if false, means can't issue motorcycle.
	 */
	private boolean fullOrNot; 
	/**
	 * get driving license number
	 * @return the driving license number.
	 */
	public String getNumber() {
		return number;
	}
	/**
	 * set driving license number
	 * @param number the number to set
	 */
	public void setNumber(String number) {
		//don't generate a person object to create a licence number here,because logically a person isn't belong to licence.
		this.number = number;
	}
	public DrivingLicence(String number, Date issueDate, boolean fullOrNot) {
		super();
		this.number = number;
		this.issueDate = issueDate;
		this.fullOrNot = fullOrNot;
	}
	/**get issueDate object.
	 * @return the issueDate
	 */
	public Date getIssueDate() {
		return issueDate;
	}
	/**set issue date.
	 * @param issueDate the issueDate to set
	 */
	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}
	/**get driving license is full or not
	 * @return the fullOrNot
	 */
	public boolean getFullOrNot() {
		return this.fullOrNot;
	}
	/**fullOrNot the fullOrNot to set
	 *
	 * @param boolean fullOrNot
	 */
	public void setFullOrNot(boolean fullOrNot) {
		this.fullOrNot = fullOrNot;
	}
	@Override
	public int hashCode() {
		return Objects.hash(fullOrNot, issueDate, number);
	}
	/**
	 * override equals method.two driving license is different if issue date or full or not or number is different. 
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;}
		if (obj == null) {
			return false;}
		if (getClass() != obj.getClass()) {
			return false;}
		DrivingLicence other = (DrivingLicence) obj;
		return fullOrNot == other.fullOrNot && Objects.equals(issueDate, other.issueDate)
				&& Objects.equals(number, other.number);
	}
	/**
	 * override toString method.
	 */
	@Override
	public String toString() {
		return "DrivingLicence [number=" + number + ", issueDate=" + issueDate + ", fullOrNot=" + fullOrNot + "]";
	}
	
}

package uk.ac.ncl.csc8404.assessment;

/**
 * @author XIAOJIN
 * @Description a motorcycle interface defines the motorcycles function.
 */
public interface Motorcycles {
		/**
		 * a method to get RegistrationNumber.
		 * @return RegistrationNumber object.
		 */
		RegistrationNumber getRegistrationNumber();
		/**
		 * a method to get the motorcycle capacity.
		 * @return integer capacity. 
		 */
		int getCapacity();
		/**
		 * a method to set current battery level.
		 * @param currentLevel
		 */
		void setCurrentLevel(int currentLevel);
		/**
		 * 
		 * a method to get the current battery level.
		 * @return integer current battery level.
		 */
		int getCurrentLevel();
		/**
		 * a method to check the motorcycle is fully charged.
		 * @return
		 */
		boolean isFullCharge();
		/**
		 * set the motorcycle full charged. Usually used in create or after returning motorcycle.
		 * @param fullCharge
		 */
		void setFullCharge(boolean fullCharge);
		/**
	     * A method to add a given amount of charge in kWh to the battery (up to the battery's capacity) and which, after execution, indicates how much charge was added.
		 * @param charge
		 * @return
		 */
		int addCharge(int charge);
		/**
		 * A method to "ride" the motorcycle for a given number of kilometers, returning the amount of kWh consumed during the journey.
		 * @param kilometers
		 * @return battery consumed.
		 */
		int ride(int kilometers);
		/**
		 * a method to set a motorcycle's registration number.
		 * @param registrationNumber
		 */
		void setRegistrationNumber(RegistrationNumber registrationNumber);
}

package uk.ac.ncl.csc8404.assessment;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Random;

/**
 * a registration number class consists of two components.
 * @author XIAOJIN
 * 
 */
public final class RegistrationNumber {
	private final String firstConponent;
	private final String secondConponent;
	private static final Map<String, RegistrationNumber> RIGISTRATION_NUMBER = new
			HashMap<String, RegistrationNumber>();
	/**
	 * verify the registration number is valid.
	 * @param firstConponent
	 * @param secondConponent
	 */
			private RegistrationNumber(String firstConponent, String secondConponent) {
			// check firstConponent and secondConponent are valid if valid then create a RegistrationNumber object.
				if(Character.isLetter(firstConponent.charAt(0))&&Character.isLetter(firstConponent.charAt(1))&&Character.isDigit(firstConponent.charAt(2))
						&&Character.isDigit(firstConponent.charAt(3))) {
					this.firstConponent = firstConponent;
					
				}else {
					this.firstConponent=null;
				}
				
				if(Character.isLetter(secondConponent.charAt(0))&&Character.isLetter(secondConponent.charAt(1))&&Character.isLetter(secondConponent.charAt(2))) {
					this.secondConponent = secondConponent;
					
				}else {
					this.secondConponent=null;
				
				}
			}
			/**
			 * randomly generate registration number.
			 * @return
			 */
			public static RegistrationNumber getInstance() {
				//generate random 2 letters and 2digits for the first part, and 3 letters for the second part
				Random random = new Random();
				//generate number between 65-90 according to ASCII
				int firstLetter = random.nextInt(26)+65;
				int secondLetter = random.nextInt(26)+65;
				//generate number 00-99 if number less than 10, add a zero before the number
			    String digits = String.format("%02d", random.nextInt(100));
				String firstConponent=(char)firstLetter+""+(char)secondLetter+digits;
			    int thirdLetter = random.nextInt(26)+65;
				int forthLetter = random.nextInt(26)+65;
				int fifthLetter = random.nextInt(26)+65;
				String secondConponent=(char)thirdLetter+""+(char)forthLetter+""+(char)fifthLetter;
			final String k = firstConponent + secondConponent;
			if (!RIGISTRATION_NUMBER.containsKey(k)) {
				RIGISTRATION_NUMBER.put(k, new RegistrationNumber(firstConponent, secondConponent));}
			return RIGISTRATION_NUMBER.get(k);
			}
			public String getFirstConponent() { return firstConponent; }
			public String getSecondConponent() { return secondConponent; }
			@Override
			public String toString() {
				return firstConponent+secondConponent;
			}
			@Override
			public int hashCode() {
				return Objects.hash(firstConponent, secondConponent);
			}
			@Override
			public boolean equals(Object obj) {
				if (this == obj) {
					return true;}
				if (obj == null) {
					return false;}
				if (getClass() != obj.getClass()) {
					return false;}
				RegistrationNumber other = (RegistrationNumber) obj;
				return Objects.equals(firstConponent, other.firstConponent)
						&& Objects.equals(secondConponent, other.secondConponent);
			}
	

}


